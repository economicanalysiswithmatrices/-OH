function varargout = RingOfFireGame(varargin)
% RINGOFFIREGAME MATLAB code for RingOfFireGame.fig
%      RINGOFFIREGAME, by itself, creates a new RINGOFFIREGAME or raises the existing
%      singleton*.
%
%      H = RINGOFFIREGAME returns the handle to a new RINGOFFIREGAME or the handle to
%      the existing singleton*.
%
%      RINGOFFIREGAME('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in RINGOFFIREGAME.M with the given input arguments.
%
%      RINGOFFIREGAME('Property','Value',...) creates a new RINGOFFIREGAME or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before RingOfFireGame_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to RingOfFireGame_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help RingOfFireGame

% Last Modified by GUIDE v2.5 10-Jan-2019 20:58:22

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @RingOfFireGame_OpeningFcn, ...
                   'gui_OutputFcn',  @RingOfFireGame_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before RingOfFireGame is made visible.
function RingOfFireGame_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to RingOfFireGame (see VARARGIN)
global var
% Choose default command line output for RingOfFireGame
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes RingOfFireGame wait for user response (see UIRESUME)
% uiwait(handles.figure1);

currentPath     = pwd;
imshow('startpic.jpg')

set(handles.PlayButton, 'UserData', 0);
imagesPath          = [currentPath,'/Images/'];
imgs                = imageDatastore(imagesPath); %read path for all images
nrOfCards           = length(imgs.Files); %find out the total number of card
var.chosenCardNr    = randperm(nrOfCards); %choose a random card
handles.MessageBox.String = 'PRESS PLAY TO START!';
messages            = cell(54,1);
messages(1:4,1)     = {'CATEGORIES - Pick a category such as football and you go in a circle and everyone has to say a word that fits with football such as: touchdown, field goal, USC. Whoever messes up, drinks.'}; %10
messages(5:8,1)     = {'CHOOSE - You can choose someone to drink'}; %2
messages(9:12,1)    = {'ME - You must drink'}; %3
messages(13:16,1)   = {'All girls drink'}; %4
messages(17:20,1)   = {'THUMB MASTER - When you put your thumb on the table everyone must follow and whomever is last must drink. You are the thumb master till someone else picks a five.'}; %5
messages(21:24,1)   = {'All guys drink'}; %6
messages(25:28,1)   = {'HEAVEN - Point your finger in the sky, whoever is last must drink'}; %7
messages(29:32,1)   = {'MATE - Choose someone to drink with you'}; %8
messages(33:36,1)   = {'RHYME - Pick a word such as dog and the person next to you must rhyme with dog, like log, and it goes to the next person and the next, in a circle, until someone messes up and he or she will have to drink'}; %9
messages(37:40,1)   = {'WATERFALL - Everyone must keep drinking until the person who picked the card stops. So who knows how long you will be going for!'}; %A
messages(41:44,1)   = {'MAKE A RULE - You can make up any rule that everyone has to follow, such as you can only drink with your right hand. Everyone (including you) must follow this rule for the whole entire game and if you disobey you must drink.'}; %J
messages(53:54,1)   = {'JOKER SURPRISE - You need to guess the next card color!'}; %Joker
messages(45:48,1)   = {'POUR!- You must pour a little of your drink into the cup that is in the middle of the table. Whomever picks up the LAST king must drink the whole cup, which could be filled with different drinks, so who knows how bad it could taste!'}; %K
messages(49:52,1)   = {'QUESTIONS - Go around in a circle and you have to keep asking questions to each other. Does not matter what the question is, as long as it is a question. Whoever messes up and does not say a question, drinks.'}; %Q

colors = cell(54,1);
for i = 1:4:49
    colors(i,1)   = {'black'};
    colors(i+1,1) = {'red'};
    colors(i+2,1) = {'red'};
    colors(i+3,1) = {'black'};
end
colors(53,1) = {'black'};
colors(54,1) = {'black'};
var.messages = messages;
var.colors   = colors;
var.counter  = 0;
var.nrPushes = 0;


% --- Outputs from this function are returned to the command line.
function varargout = RingOfFireGame_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in PlayButton.
function PlayButton_Callback(hObject, eventdata, handles)
% hObject    handle to PlayButton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global var
set(handles.BlackButton,'Visible','off')
set(handles.Redpushbutton,'Visible','off')

ispushed        = get(handles.PlayButton,'Value');
guidata(hObject, handles);
currentPath     = pwd;
imagesPath      = [currentPath,'/Images/'];
imgs            = imageDatastore(imagesPath); %read path for all images
nrOfCards       = length(imgs.Files); %find out the total number of card

if ispushed
    if var.nrPushes <= 1
    var.counter     = var.counter +1;
    end
    chosenCardNr    = var.chosenCardNr(var.counter); %choose a random card
    chosenPath      = char(imgs.Files(chosenCardNr)); % random's card path
    imshow(chosenPath);
    handles.MessageBox.String = char(var.messages(chosenCardNr,1));
    drawnow;
    if chosenCardNr == 53 || chosenCardNr == 54
        set(handles.BlackButton,'Visible','on')
        set(handles.Redpushbutton,'Visible','on')
        set(handles.PlayButton,'Visible','off')
        var.counter = var.counter+1;        
    end
    
    if var.counter == nrOfCards % if you run out of cards, end game
        %warndlg('The Game is over! Relaunch to play again!')
        set(handles.PlayButton,'Visible','off')
        set(handles.QuitButton,'Visible','on')
        QuitButton_Callback(hObject, eventdata, handles)
        handles.MessageBox.String = 'The game is over!  Everybody drinks double!';
    end
end


% --- If Enable == 'on', executes on mouse press in 5 pixel border.
% --- Otherwise, executes on mouse press in 5 pixel border or over PlayButton.
function PlayButton_ButtonDownFcn(hObject, eventdata, handles)
% hObject    handle to PlayButton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)



% --- Executes on button press in BlackButton.
function BlackButton_Callback(hObject, eventdata, handles)
% hObject    handle to BlackButton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global var
nextCardColor   = char(var.colors(var.chosenCardNr(var.counter)));
currentPath     = pwd;
imagesPath      = [currentPath,'/Images/'];
imgs            = imageDatastore(imagesPath); %read path for all images

ispushed        = get(handles.BlackButton,'Value');

if ispushed 
    var.nrPushes = var.nrPushes + 1;
     %var.counter = var.counter + 1;
    if strcmp(nextCardColor,'black')
        handles.MessageBox.String = ['Congratuations! You guessed corectly! If you keep guessing,the quantities will double! If you stop here everyone else will drink ',num2str(2^(var.nrPushes-1)),' glasses ! Stop here?'];
        set(handles.YesButton,'Visible','on')
        set(handles.NoButton,'Visible','on')
        set(handles.BlackButton,'Visible','off')
        set(handles.Redpushbutton,'Visible','off')
    else
        handles.MessageBox.String = ['WRONG! You must drink ',num2str(2^(var.nrPushes-1)),' glasses !'];
        set(handles.YesButton,'Visible','off')
        set(handles.NoButton,'Visible','off')
        set(handles.BlackButton,'Visible','off')
        set(handles.Redpushbutton,'Visible','off')
        set(handles.PlayButton,'Visible','on')
        var.nrPushes = 0;
    end

    chosenCardNr    = var.chosenCardNr(var.counter); 
    chosenPath      = char(imgs.Files(chosenCardNr)); % random's card path
    imshow(chosenPath)
    %handles.MessageBox.String = char(var.messages(chosenCardNr,1));
    drawnow;
         var.counter = var.counter + 1;
end




% --- Executes on button press in Redpushbutton.
function Redpushbutton_Callback(hObject, eventdata, handles)
% hObject    handle to Redpushbutton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global var
nextCardColor   = char(var.colors(var.chosenCardNr(var.counter)));
currentPath     = pwd;
imagesPath      = [currentPath,'/Images/'];
imgs            = imageDatastore(imagesPath); %read path for all images

ispushed        = get(handles.Redpushbutton,'Value');

if ispushed 
    var.nrPushes = var.nrPushes + 1;

    if strcmp(nextCardColor,'red')
        handles.MessageBox.String = ['Congratuations! You guessed corectly! If you keep guessing,the quantities will double! If you stop here everyone else will drink ',num2str(2^(var.nrPushes-1)),' glasses ! Stop here?'];
        set(handles.YesButton,'Visible','on')
        set(handles.NoButton,'Visible','on')
        set(handles.BlackButton,'Visible','off')
        set(handles.Redpushbutton,'Visible','off')
    else
        handles.MessageBox.String = ['WRONG! You must drink ',num2str(2^(var.nrPushes-1)),' glasses !'];
        set(handles.YesButton,'Visible','off')
        set(handles.NoButton,'Visible','off')
        set(handles.BlackButton,'Visible','off')
        set(handles.Redpushbutton,'Visible','off')
        set(handles.PlayButton,'Visible','on')
        var.nrPushes = 0;
    end
    
    chosenCardNr    = var.chosenCardNr(var.counter); %choose a random card
    chosenPath      = char(imgs.Files(chosenCardNr)); % random's card path
    imshow(chosenPath)
    %handles.MessageBox.String = char(var.messages(chosenCardNr,1));
    drawnow;
    var.counter = var.counter + 1;
end


% --- Executes on button press in YesButton.
function YesButton_Callback(hObject, eventdata, handles)
% hObject    handle to YesButton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global var
ispushed        = get(handles.YesButton,'Value');
if ispushed
    set(handles.YesButton,'Visible','off')
    set(handles.NoButton,'Visible','off')
    set(handles.Redpushbutton,'Visible','off')
    set(handles.BlackButton,'Visible','off')
    set(handles.PlayButton,'Visible','on')
    var.nrPushes = 0;
    PlayButton_Callback(hObject, eventdata, handles)
end


% --- Executes on button press in NoButton.
function NoButton_Callback(hObject, eventdata, handles)
% hObject    handle to NoButton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
ispushed        = get(handles.NoButton,'Value');
if ispushed
    set(handles.Redpushbutton,'Visible','on')
    set(handles.BlackButton,'Visible','on')
    Redpushbutton_Callback(hObject, eventdata, handles)
    BlackButton_Callback(hObject, eventdata, handles)
end


% --- Executes on button press in QuitButton.
function QuitButton_Callback(hObject, eventdata, handles)
% hObject    handle to QuitButton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
ispushed        = get(handles.QuitButton,'Value');
if ispushed
    delete(handles.figure1);
end 


% --- Executes on button press in togglebutton2.
function togglebutton2_Callback(hObject, eventdata, handles)
% hObject    handle to togglebutton2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of togglebutton2
while get(hObject,'Value')
    [Y,Fs] =audioread('ne-yo-so-sick.mp3');
p = audioplayer(Y,Fs)
play(p)
pause(292)
end

